# EVALUACION-PROCESOS
REPORTE DE EVALUACIÓN DE PROCESOS ADMINISTRATIVOS DEL ALMACÉN

## Generador de reportes (`index.html`)
Abre `index.html` en el navegador, sube el Excel del mes y obtén el reporte **RUTAS PENDIENTES EN BEETRACK**:
solo órdenes en estado Pendiente, folio solo con números y cuadro de cumplimiento por sucursal
(gerente 16.66 %, administrativo 20 %; con órdenes pendientes el cumplimiento es "No" y el ponderado 0 %).

Los pesos, sucursales y alias de nombres están al inicio del script (`PESOS`, `SUCURSALES`, `ALIAS`).

## Base de datos (Supabase)
- Esquema: `supabase/migrations/`.
- Tablas: `reporte_periodos`, `rutas_pendientes`, `rutas_resultado`.
- El botón **Guardar en Supabase** reemplaza los datos del mes detectado en el nombre del archivo (por ejemplo `..._SEP-2026.xlsx`).
- Requiere iniciar sesión: las tablas tienen RLS y solo escriben usuarios autenticados.
- No subas los Excel de operación al repositorio.
